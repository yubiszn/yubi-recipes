import 'package:flutter/material.dart';

class AboutPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('About'),
      ),
      body: SingleChildScrollView(
        padding: EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Center(
              child: Image.asset(
                'assets/images/recipe.png',
                width: 500,
                height: 210,
                fit: BoxFit.cover,
              ),
            ),
            SizedBox(height: 20),
            Text(
              'App Description',
              style: TextStyle(
                fontSize: 20,
                fontWeight: FontWeight.bold,
                color: const Color.fromARGB(255, 133, 39, 39),
              ),
            ),
            SizedBox(height: 10),
            Text(
              'This is a food recipe app that uses the Yummly API to fetch recipes. It allows users to explore and access a wide variety of recipes. Recipes come equipped with information about each recipe including cook time and rating.',
              style: TextStyle(
                fontSize: 16,
                color: Colors.black87,
              ),
            ),
            SizedBox(height: 20),
            Text(
              'Features',
              style: TextStyle(
                fontSize: 20,
                fontWeight: FontWeight.bold,
                color: const Color.fromARGB(255, 133, 39, 39),
              ),
            ),
            SizedBox(height: 10),
            Text(
              '- Browse scrumptious and delicious recipes\n'
              '- Access to recipe images, ratings, and cook time fetched from Yummly API',
              style: TextStyle(
                fontSize: 16,
                color: Colors.black87,
              ),
            ),
            SizedBox(height: 20),
            Text(
              'Additional Information',
              style: TextStyle(
                fontSize: 16,
                fontWeight: FontWeight.bold,
                color: const Color.fromARGB(255, 133, 39, 39),
              ),
            ),
            SizedBox(height: 10),
            Text(
              'Creator: Ayub Ali\n'
              'Class: WEBD 325\n'
              'Professor: Clark Powell',
              style: TextStyle(
                fontSize: 16,
                color: Colors.black87,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
