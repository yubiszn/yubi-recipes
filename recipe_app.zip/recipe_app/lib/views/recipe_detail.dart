import 'package:flutter/material.dart';
import 'package:recipe_app/models/recipe.dart';

class RecipeDetailPage extends StatelessWidget {
  final Recipe recipe;

  RecipeDetailPage({required this.recipe});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(recipe.name),
      ),
      body: Padding(
        padding: EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Image.network(recipe.images),
            SizedBox(height: 10),
            Text(
              recipe.name,
              style: TextStyle(
                fontSize: 24,
                fontWeight: FontWeight.bold,
                color: Colors.black, // Color for recipe name
              ),
            ),
            SizedBox(height: 10),
            Text(
              'Rating: ${recipe.rating}',
              style: TextStyle(
                fontSize: 18,
                color: const Color.fromARGB(255, 133, 39, 39),
                fontWeight: FontWeight.w600,
              ),
            ),
            SizedBox(height: 10),
            Text(
              'Cook Time: ${recipe.totalTime}',
              style: TextStyle(
                fontSize: 18,
                color: const Color.fromARGB(255, 31, 99, 155), 
                fontWeight: FontWeight.w600,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
